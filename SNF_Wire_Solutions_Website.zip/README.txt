# SNF Wire Solutions Website

A static, mobile-friendly website for SNF Wire Solutions.

## Files
- index.html — website content
- style.css — styling

## Quick test
Open `index.html` in a web browser.

## Publish
This site can be uploaded to a normal web host or deployed using services such as GitHub Pages, Netlify, Vercel, or a traditional hosting provider.

## Important
The quote form uses a mailto action. For a professional production website, replace it later with a real form endpoint so quote requests are captured reliably and customers can upload drawings/BOMs.
